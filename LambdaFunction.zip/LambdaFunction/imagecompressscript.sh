#!/bin/bash
PROGNAME=${0##*/}
INPUT=''
QUIET='0'

# $1: input image
# $2: output image
optimize_image()
{
        if [ "${1##*.}" = "png" ]; then
                convert $1 -strip $2
        fi
        if [ "${1##*.}" = "gif" ]; then
                convert $1 -strip $2
        fi
        if [ "${1##*.}" = "jpg" -o "${1##*.}" = "jpeg" ]; then
                convert $1 -sampling-factor 4:2:0 -strip -quality 85 -interlace JPEG -colorspace RGB $2
        fi        

}

main()
{
        # We create the output directory
        #mkdir -p $(pwd)/output/image

        # Search of all jpg/jpeg/png in $INPUT
        # We remove images from $OUTPUT if $OUTPUT is a subdirectory of $INPUT
        find -E /Users/poovizhichandramohan/Downloads/tryme/input -type f -regex '.*\.(jpg|jpeg|png|gif)' | while read IMAGES; do
                directoryfullpath=$(dirname $IMAGES)
                echo $directoryfullpath

                inputdirectorypath=$(pwd)/input
                directorytrimmedpath=${directoryfullpath#*$inputdirectorypath}
                echo $directorytrimmedpath

                mkdir -p $(pwd)/output/$directorytrimmedpath

                filename=$(basename $IMAGES)
                echo $filename

                optimize_image $IMAGES $(pwd)/output/$directorytrimmedpath/$filename
        done
}


SHORTOPTS="i:,o:,q"
LONGOPTS="input:,output:,quiet"
ARGS=$(getopt -s bash --options $SHORTOPTS --longoptions $LONGOPTS --name $PROGNAME -- "$@")

eval set -- "$ARGS"
while true; do
        case $1 in
                --)
                        shift
                        break
                        ;;
                *)
                        shift
                        break
                        ;;
        esac
        shift
done

main