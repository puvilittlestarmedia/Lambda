var async = require('async');
var AWS = require('aws-sdk');


var util = require('util');
var im = require('imagemagick');
var fs = require('fs');

// constants
var MAX_WIDTH  = 100;
var MAX_HEIGHT = 100;

var s3 = require('s3');

var client = s3.createClient({
  maxAsyncS3: 20,     // this is the default
  s3RetryCount: 3,    // this is the default
  s3RetryDelay: 1000, // this is the default
  multipartUploadThreshold: 20971520, // this is the default (20 MB)
  multipartUploadSize: 15728640, // this is the default (15 MB)
  s3Options: {
    accessKeyId: "AKIAI4DB7E4MLNYQAUVA",
    secretAccessKey: "7K0T5QgRyjgXy6OYraOJ0nmWJGZ715FTkL44jN6r",
    // endpoint: 's3.yourdomain.com',
    // sslEnabled: false
    // any other options are passed to new AWS.S3()
    // See: http://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/Config.html#constructor-property
  },
});

 
exports.handler = function(event, context, callback) {
    // Read options from the event.
    console.log("Reading options from event:\n", util.inspect(event, {depth: 5}));
    var srcBucket = event.Records[0].s3.bucket.name;
    // Object key may have spaces or unicode non-ASCII characters.
    var srcKey    = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, " "));  
    var dstBucket = srcBucket + "resized";
    var dstKey    = "resized-" + srcKey;

    // Sanity check: validate that source and destination are different buckets.
    if (srcBucket == dstBucket) {
        callback("Source and destination buckets are the same.");
        return;
    }

    // Infer the image type.
    var typeMatch = srcKey.match(/\.([^.]*)$/);
    if (!typeMatch) {
        callback("Could not determine the image type.");
        return;
    }
    var imageType = typeMatch[1];
    if (imageType != "jpg" && imageType != "png") {
        callback('Unsupported image type: ${imageType}');
        return;
    }

    // Download the image from S3, transform, and upload to a different S3 bucket.
    async.waterfall([
        function download(next) {

            var params = {
              localFile: "/tmp/"+srcKey,

              s3Params: {
                Bucket: srcBucket,
                Key: srcKey,
                // other options supported by getObject
                // See: http://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/S3.html#getObject-property
              },
            };
            var downloader = client.downloadFile(params);
            downloader.on('error', function(err) {
              console.error("unable to download:", err.stack);
            });
            downloader.on('progress', function() {
              console.log("progress", downloader.progressAmount, downloader.progressTotal);
            });
            downloader.on('end', function() {
                    console.log("done downloading");

                    im.convert(["/tmp/"+srcKey, 
                            '-sampling-factor','4:2:0',
                            '-strip',
                            '-quality', '85',
                            '-interlace', 'JPEG',
                            '-colorspace','RGB', 
                            "/tmp/"+srcKey], 
                    function(err, stdout){
                      if (err) throw err;
                        console.log('stdout:', stdout);

                        //upload a file
                        var uploadparams = {
                          localFile: "/tmp/"+srcKey,

                          s3Params: {
                            Bucket: dstBucket,
                            Key: dstKey,
                            // other options supported by putObject, except Body and ContentLength.
                            // See: http://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/S3.html#putObject-property
                          },
                        };
                        var uploader = client.uploadFile(uploadparams);
                        uploader.on('error', function(err) {
                          console.error("unable to upload:", err.stack);
                        });
                        uploader.on('progress', function() {
                          console.log("progress", uploader.progressMd5Amount,
                                    uploader.progressAmount, uploader.progressTotal);
                        });
                        uploader.on('end', function() {
                          console.log("done uploading");
                        });    

                    });          
            });


        }

    ], function (err) {
            if (err) {
                console.error(
                    'Unable to resize ' + srcBucket + '/' + srcKey +
                    ' and upload to ' + destBucket + '/' + destKey +
                    ' due to an error: ' + err
                );
            } else {
                console.log(
                    'Successfully resized ' + srcBucket + '/' + srcKey +
                    ' and uploaded to ' + destBucket + '/' + destKey
                );
            }
        }
    );          
};